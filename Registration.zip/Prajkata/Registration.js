import { StatusBar } from 'expo-status-bar';
import { Formik } from 'formik';
import React from 'react';
import { Button, StyleSheet, Text, View ,TextInput, ImageBackground} from 'react-native';
import {withFormik} from 'formik';

class Registration extends React.Component{
    state={
        name:"",
        email:"",
        password:""
      }

    static navigationOptions = {
        title: 'Register',
         };
    render(){
            const { navigate, state } = this.props.navigation;
            return(
               
    
    <View>
        <ImageBackground source={require('./assets/images.jpg')} style={{width:null,height:900,flex:1,justifyContent:'center'}}>
        <TextInput  
        value={this.state.name}  
        onChangeText={name => this.setState({ name })}  
        placeholder={'Enter Name'}  
        style={{height:42,width:"80%",borderBottomWidth:1}}
        />  
        <Text>{"\n"}</Text>
         <TextInput  
        value={this.state.email}  
        onChangeText={email => this.setState({ email })}  
        placeholder={'Enter Email'}  
        style={{height:42,width:"80%",borderBottomWidth:1}}
        />  
        <Text>{"\n"}</Text>
        <TextInput  
        value={this.state.password} 
        secureTextEntry={true} 
        onChangeText={password => this.setState({ password })}  
        placeholder={'Enter Password'}  
        style={{height:42,width:"80%",borderBottomWidth:1}}
        />  
        <Text>{"\n"}</Text>
        <Text>{"\n"}</Text>
        <Button  
        title="Register"  
         
        onPress={() =>  
        this.props.navigation.navigate('Details', {  
            email: this.state.email
            
        })  
        }  
        />  

                
               
     
        </ImageBackground>
    </View>
           
         
        );

    }

}

const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: '#fff',
      alignItems: 'center',
      justifyContent: 'center',
    },
    validatetext:{
      color:'red'
    }
  });
  
  
  export default withFormik({
  mapPropsToValues: () => ({email:"",password:""}),
  validate:(values,props) => {
      const errors={};
      if(!values.email){
        errors.email='Email Required';
        
      }
  
      if(!values.password){
        errors.password='Password Required';
      }else if(values.password.length<8) {
            errors.password='Minimum length of password is 8 character';
      }
      return errors;
  },

  })(Registration);