import React from 'react';
import { View, Text, Button } from 'react-native';
import { createAppContainer } from 'react-navigation';
import { createStackNavigator } from 'react-navigation-stack';

import Registration from './Registration';
import Details from './Details';


const Navigator = createStackNavigator({
   

   Registration:{screen:Registration},

   Details:{screen:Details}
     
});



const App = createAppContainer(Navigator);

export default App;
