import { StatusBar } from 'expo-status-bar';
import React,{useState} from 'react';
import { StyleSheet, Text, View,Button,TextInput,ImageBackground } from 'react-native';
import {createAppContainer}from 'react-navigation';
import{createStackNavigator}from 'react-navigation-stack';
import Login from "./Login";
import Register from './Register';

//{navigation}
function App (props){
  
  const username="Prajakta";
  const password="Prajakta@23";
  const [name, setName] = useState('');
  const [pass, setPass] = useState('');

  const Handle = () =>
  {
  //  alert("...");
   // name=="Prajakta" && pass=="Prajakta@23"? <Login/>   : null
   (name=="Prajakta"&&pass=="Prajakta23")?props.navigation.navigate('Login'):props.navigation.navigate('Register')
   //navigation.navigate('Login');
  }
  
  
  return (
    <View style={styles.container}>
      <ImageBackground source = {require('./assets/images.jpg')} style={{flex:1,width: null, height: null}}>

      <Text style={{fontSize:40}}>Welcome to App{'\n' }</Text>
    
        <Text style={{fontSize:20}}>Name</Text>
        { /* <View>
        <TextInput   maxLength={15} 
         placeholder={'Enter User Name'} 
         onChangeText={(name)=>setName(name)}/>
         </View>*/}
      <TextInput style={{backgroundColor:'white'}} placeholder="Enter name"  onChangeText={(e)=>{setName({name:e})}} ></TextInput>
        <br/>
        <Text style={{fontSize:20}}>Password</Text>
        <TextInput style={{backgroundColor:'white'}} placeholder="Enter password"  onChangeText={(e)=>{setPass({pass:e})}} ></TextInput>
       {console.log(name)} 
        <br/>
        {/* <Button onPress={Handle} title="Login"/ >*/}
    {/*<Button onPress={()=>{props.navigation.navigate("Profile")}} title="Login"/ >*/}
    <Button onPress={Handle}  title="Login"/ >
          <br/>
          <br/>
          </ImageBackground>

    </View>
  );
}


const appNavigator=createStackNavigator(
  {
    Home: 
    {
      screen: App
     
    },
    Login:
 {
  screen: Login
 
}
 ,
 Register:Register 
      
  }
)
export default createAppContainer(appNavigator);
const styles = StyleSheet.create({
  container: {
    flex: 1,
  //  backgroundColor: 'orange',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
