import { StatusBar } from 'expo-status-bar';
import React from 'react';
import { render } from 'react-dom';
import { StyleSheet, Text, View ,Button,TextInput,ImageBackground} from 'react-native';
export default class Register extends React.Component {

render()
{
    return (
        <View style={styles.container}>
             <ImageBackground source = {require('./assets/images.jpg')} style={{flex:1,width: null, height: null}}>
          <Text style={{fontSize:40}}>Welcome to Register page</Text>
          </ImageBackground>
     
        </View>
      );
}

}
const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: 'orange',
      alignItems: 'center',
      justifyContent: 'center',
    },
  });